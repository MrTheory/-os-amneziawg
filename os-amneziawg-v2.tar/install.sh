#!/bin/sh
# AmneziaWG OPNsense Plugin Installer
# Tested on OPNsense 25.x / FreeBSD 14.3

set -e

PLUGIN_DIR="$(dirname "$0")/plugin"
AWG_KMOD="https://pkg.freebsd.org/FreeBSD:14:amd64/quarterly/All/Hashed/amnezia-kmod-2.0.10.1403000~eed49ec054.pkg"
AWG_TOOLS="https://pkg.freebsd.org/FreeBSD:14:amd64/quarterly/All/Hashed/amnezia-tools-1.0.20250903~ca774170ae.pkg"

echo "==> Step 1: Installing AmneziaWG packages..."
pkg add "$AWG_KMOD" || true
pkg add "$AWG_TOOLS" || true

echo "==> Step 2: Loading kernel module..."
kldload if_amn 2>/dev/null || true
grep -q 'if_amn_load' /boot/loader.conf || echo 'if_amn_load="YES"' >> /boot/loader.conf

echo "==> Step 3: Verifying..."
awg --version || { echo "ERROR: awg not found!"; exit 1; }

echo "==> Step 4: Installing plugin files..."

install -d /usr/local/opnsense/scripts/AmneziaWG
install -m 0755 "$PLUGIN_DIR/scripts/AmneziaWG/amneziawg-service-control.php" /usr/local/opnsense/scripts/AmneziaWG/
install -m 0644 "$PLUGIN_DIR/service/conf/actions.d/actions_amneziawg.conf" /usr/local/opnsense/service/conf/actions.d/
install -d /usr/local/opnsense/mvc/app/models/OPNsense/AmneziaWG/Menu
install -m 0644 "$PLUGIN_DIR/mvc/app/models/OPNsense/AmneziaWG/General.xml" /usr/local/opnsense/mvc/app/models/OPNsense/AmneziaWG/
install -m 0644 "$PLUGIN_DIR/mvc/app/models/OPNsense/AmneziaWG/General.php" /usr/local/opnsense/mvc/app/models/OPNsense/AmneziaWG/
install -m 0644 "$PLUGIN_DIR/mvc/app/models/OPNsense/AmneziaWG/Instance.xml" /usr/local/opnsense/mvc/app/models/OPNsense/AmneziaWG/
install -m 0644 "$PLUGIN_DIR/mvc/app/models/OPNsense/AmneziaWG/Instance.php" /usr/local/opnsense/mvc/app/models/OPNsense/AmneziaWG/
install -m 0644 "$PLUGIN_DIR/mvc/app/models/OPNsense/AmneziaWG/Menu/Menu.xml" /usr/local/opnsense/mvc/app/models/OPNsense/AmneziaWG/Menu/
install -d /usr/local/opnsense/mvc/app/controllers/OPNsense/AmneziaWG/Api
install -d /usr/local/opnsense/mvc/app/controllers/OPNsense/AmneziaWG/forms
install -m 0644 "$PLUGIN_DIR/mvc/app/controllers/OPNsense/AmneziaWG/IndexController.php" /usr/local/opnsense/mvc/app/controllers/OPNsense/AmneziaWG/
install -m 0644 "$PLUGIN_DIR/mvc/app/controllers/OPNsense/AmneziaWG/Api/GeneralController.php" /usr/local/opnsense/mvc/app/controllers/OPNsense/AmneziaWG/Api/
install -m 0644 "$PLUGIN_DIR/mvc/app/controllers/OPNsense/AmneziaWG/Api/InstanceController.php" /usr/local/opnsense/mvc/app/controllers/OPNsense/AmneziaWG/Api/
install -m 0644 "$PLUGIN_DIR/mvc/app/controllers/OPNsense/AmneziaWG/Api/ServiceController.php" /usr/local/opnsense/mvc/app/controllers/OPNsense/AmneziaWG/Api/
install -m 0644 "$PLUGIN_DIR/mvc/app/controllers/OPNsense/AmneziaWG/Api/ImportController.php" /usr/local/opnsense/mvc/app/controllers/OPNsense/AmneziaWG/Api/
install -m 0644 "$PLUGIN_DIR/mvc/app/controllers/OPNsense/AmneziaWG/forms/general.xml" /usr/local/opnsense/mvc/app/controllers/OPNsense/AmneziaWG/forms/
install -m 0644 "$PLUGIN_DIR/mvc/app/controllers/OPNsense/AmneziaWG/forms/dialogEditInstance.xml" /usr/local/opnsense/mvc/app/controllers/OPNsense/AmneziaWG/forms/
install -d /usr/local/opnsense/mvc/app/views/OPNsense/AmneziaWG
install -m 0644 "$PLUGIN_DIR/mvc/app/views/OPNsense/AmneziaWG/general.volt" /usr/local/opnsense/mvc/app/views/OPNsense/AmneziaWG/
install -m 0644 "$PLUGIN_DIR/etc/inc/plugins.inc.d/amneziawg.inc" /usr/local/etc/inc/plugins.inc.d/
install -d -m 0700 /usr/local/etc/amnezia

echo "==> Step 5: Restarting configd..."
service configd restart

echo "==> Step 6: Clearing cache..."
rm -f /var/lib/php/tmp/opnsense_menu_cache.xml
rm -f /var/lib/php/tmp/PHP_errors.log

echo ""
echo "=============================="
echo " AmneziaWG plugin installed!"
echo "=============================="
echo "Refresh browser and go to VPN -> AmneziaWG"
